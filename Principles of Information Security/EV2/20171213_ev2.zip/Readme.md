For the file to work,

packages needed : sympy, numpy

Before running:
1. pip3 install sympy
2. pip3 install numpy

and then run
using python3 20171213.py


or using jupiter notebook provided on google colab
